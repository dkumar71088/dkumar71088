package com.editorial.aspirants

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/**
 * Configure authorized editorial sources here. These are the publishers' own public RSS
 * feeds. Verify the URLs and each publisher's terms; replace with a licensed feed/API if you
 * have one. Feeds only carry recent items, so older dates will honestly show "none available".
 */
object Sources {
    val feeds: Map<String, String> = linkedMapOf(
        "The Hindu" to "https://www.thehindu.com/opinion/editorial/feeder/default.rss",
        "The Indian Express" to "https://indianexpress.com/section/opinion/editorials/feed/"
    )
}

data class Article(val title: String, val link: String, val date: LocalDate, val author: String?)

object Repo {
    suspend fun download(url: String): String = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "EditorialAspirants/0.1")
        try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    /** Parses RSS items. Items without a parseable date are skipped, never invented. */
    fun parse(xml: String): List<Article> {
        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        val out = mutableListOf<Article>()
        var inItem = false
        var title = ""; var link = ""; var pub = ""; var author: String? = null
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item" -> { inItem = true; title = ""; link = ""; pub = ""; author = null }
                    "title" -> if (inItem) title = p.nextText().trim()
                    "link" -> if (inItem) link = p.nextText().trim()
                    "pubDate" -> if (inItem) pub = p.nextText().trim()
                    "dc:creator", "creator", "author" -> if (inItem) author = p.nextText().trim()
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                inItem = false
                val d = runCatching {
                    ZonedDateTime.parse(pub, DateTimeFormatter.RFC_1123_DATE_TIME)
                        .withZoneSameInstant(ZoneId.of("Asia/Kolkata")).toLocalDate()
                }.getOrNull()
                if (title.isNotEmpty() && link.isNotEmpty() && d != null)
                    out.add(Article(title, link, d, author?.takeIf { it.isNotEmpty() }))
            }
            ev = p.next()
        }
        return out
    }
}
