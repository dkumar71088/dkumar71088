package com.editorial.aspirants

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

val Navy = Color(0xFF0B1F4B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Navy, background = Color.White, surface = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = Color.White) { App() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Dropdown(label: String, value: String, options: List<String>, modifier: Modifier,
             enabled: (Int) -> Boolean = { true }, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = { open = it }, modifier = modifier) {
        OutlinedTextField(value = value, onValueChange = {}, readOnly = true, singleLine = true,
            label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(open) },
            modifier = Modifier.menuAnchor())
        ExposedDropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, o ->
                DropdownMenuItem(text = { Text(o) }, enabled = enabled(i),
                    onClick = { open = false; onPick(i) })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("editorial", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val today = remember { LocalDate.now() }
    val papers = remember { Sources.feeds.keys.toList() }
    var paper by remember { mutableStateOf(prefs.getString("paper", papers[0])!!.takeIf { it in papers } ?: papers[0]) }
    var date by remember { mutableStateOf(runCatching { LocalDate.parse(prefs.getString("date", null)) }.getOrDefault(today)) }
    var articles by remember { mutableStateOf(listOf<Article>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var updated by remember { mutableStateOf<String?>(null) }

    fun setDate(y: Int, m: Int, d: Int) {
        date = LocalDate.of(y, m, minOf(d, YearMonth.of(y, m).lengthOfMonth()))
        prefs.edit().putString("date", date.toString()).apply()
    }

    fun load() {
        scope.launch {
            loading = true; error = null
            try {
                val xml = Repo.download(Sources.feeds[paper]!!)
                prefs.edit().putString("xml_$paper", xml).putLong("upd_$paper", System.currentTimeMillis()).apply()
            } catch (e: Exception) {
                error = "Couldn't reach the newspaper feed (${e.javaClass.simpleName}). Showing saved data if available."
            }
            val xml = prefs.getString("xml_$paper", null)
            articles = if (xml != null) runCatching { Repo.parse(xml) }.getOrDefault(emptyList()) else emptyList()
            val u = prefs.getLong("upd_$paper", 0L)
            updated = if (u > 0) java.text.SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH).format(java.util.Date(u)) else null
            loading = false
        }
    }
    LaunchedEffect(paper) { load() }

    val shown = articles.filter { it.date == date }
    val months = remember { (1..12).map { java.time.Month.of(it).getDisplayName(TextStyle.FULL, Locale.ENGLISH) } }
    val years = remember { (today.year downTo today.year - 5).toList() }
    val fmt = DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH)

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Navy).padding(16.dp)) {
                Text("Editorial for Civil Services Aspirants", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Daily Editorials for UPSC & PCS Preparation", color = Color(0xFFCBD5F0), fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Text("Today: ${today.format(fmt)}", color = Color.White, fontSize = 14.sp)
            }
        }
        item {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Dropdown("Newspaper", paper, papers, Modifier.fillMaxWidth()) {
                    paper = papers[it]; prefs.edit().putString("paper", paper).apply()
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val max = YearMonth.of(date.year, date.monthValue).lengthOfMonth()
                    Dropdown("Day", date.dayOfMonth.toString(), (1..31).map { it.toString() }, Modifier.weight(0.7f),
                        enabled = { it + 1 <= max }) { setDate(date.year, date.monthValue, it + 1) }
                    Dropdown("Month", months[date.monthValue - 1], months, Modifier.weight(1.3f)) {
                        setDate(date.year, it + 1, date.dayOfMonth)
                    }
                    Dropdown("Year", date.year.toString(), years.map { it.toString() }, Modifier.weight(1f),
                        enabled = { true }) { setDate(years[it], date.monthValue, date.dayOfMonth) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { setDate(today.year, today.monthValue, today.dayOfMonth) }) { Text("Today") }
                    Button(onClick = { load() }, enabled = !loading,
                        colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("Refresh") }
                }
                Text(updated?.let { "Last successful update: $it" } ?: "Not yet updated successfully", fontSize = 12.sp, color = Color.Gray)
            }
        }
        item {
            Text(if (date == today) "Today's Editorial Headlines" else "Editorial Headlines — ${date.format(fmt)}",
                Modifier.padding(horizontal = 16.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy)
            Spacer(Modifier.height(8.dp))
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Navy)
            error?.let { Text(it, Modifier.padding(16.dp), color = Color(0xFFB00020), fontSize = 13.sp) }
            if (!loading && shown.isEmpty())
                Text("No editorial is available for this date from the configured official feed. " +
                    "Feeds only carry recent items; try Today or a recent date.",
                    Modifier.padding(16.dp), fontSize = 14.sp)
        }
        items(shown) { a ->
            Card(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F5FC))) {
                Column(Modifier.padding(14.dp)) {
                    Text(a.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Navy)
                    Spacer(Modifier.height(4.dp))
                    Text("$paper • ${a.date.format(fmt)}" + (a.author?.let { " • $it" } ?: ""), fontSize = 12.sp, color = Color.DarkGray)
                    Text("Tap to read on the original site", fontSize = 12.sp, color = Navy)
                }
            }
        }
    }
}
