# Editorial for Civil Services Aspirants (MVP)
Kotlin + Jetpack Compose. Newspaper dropdown, day/month/year selectors (invalid days disabled), Today, Refresh,
last-update time, headline cards linking to the original article. No fake data: if a feed is down or has nothing
for the date, the app says so. Last feed is cached for offline viewing.

## Build the APK (no local SDK needed)
1. Create a GitHub repo, upload this folder's contents, push to `main`.
2. Actions tab -> "Build APK" -> download the `editorial-app-apk` artifact.
3. Unzip, copy `app-debug.apk` to the phone, allow "install unknown apps", tap to install.
(Or in Android Studio: open the folder, Build > Build APK.)

## Configure sources
Edit `Sources.feeds` in `Repo.kt`. Verify each publisher's terms; swap in a licensed feed/API or your own
backend if you have one. Never put secret keys in the app.

## Not yet built (next phase)
Bookmarks, notes, search, categories, vocabulary, share, dark mode, summaries/GS tagging.
